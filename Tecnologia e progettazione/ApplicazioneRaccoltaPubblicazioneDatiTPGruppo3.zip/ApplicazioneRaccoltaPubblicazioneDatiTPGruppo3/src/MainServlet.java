import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;

public class MainServlet extends javax.servlet.http.HttpServlet {
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {

    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        final  String urlDB ="jdbc:mariadb://localhost:3306/musica";
        final  String utenteDB ="root";
        final  String passwordDB ="";
        PrintWriter out = response.getWriter();
        response.setContentType("text/html");

        URL urlCSV = new URL(request.getParameter("url"));
        //out.println(request.getParameter("url"));
        // ...
        // establish connection to file in URL
        URLConnection urlConn = urlCSV.openConnection();
        // ...
        InputStreamReader inputCSV = new InputStreamReader(((URLConnection) urlConn).getInputStream());
        // ...
        BufferedReader br = new BufferedReader(inputCSV);
        // ...
        // Declare String to hold file to Split from URL
        String line;
        /*String RoleNameVal = RoleNameValue.toString();
        String UserNameVal = UserNameValue.toString();
        String PageIDVal = PageID.toString();*/
        // ...
        // Read file accordingly
        while ((line = br.readLine()) != null) {
            // ...
            // Split file based on Delimiter in question "MyStrToMyDotoboseSectoid"
            String[] values = line.split(","); // separator
            //out.println(line+"<br>");
            // ...
            // Declare and plug values obtained from Split
            String strPostID = values[0];
            out.println(strPostID+"<br>");
            /*String strPostName = values[1];
            String strPostMessage = values[2];
            String strPostDate = values[3];
            String strPostURL = values[4];
            String strPostStamp = values[5];
            String str2 = values[6];
            String str3 = values[7];
            String str4 = values[8];
            String str234 = values[9];
            String asdasd = values[10];
            String asdasdasd = values[11];
            String sd = values[12];
            String asd = values[13];
            String strasdasdPostID = values[14];
            String asdds = values[15];
            String strPodasdsstID = values[16];
            String strPodsdsstID = values[17];
            String stsdrPostID = values[18];
            String strPodsstID = values[19];*/

        }
        out.format("fine iterazione%n");
    }
}
